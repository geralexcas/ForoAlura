package ForoAlura.foro.record.curso.usuario;

public record DatosRespuestaUsuario(
        Long id,
        String nombre,
        String email) {
}
