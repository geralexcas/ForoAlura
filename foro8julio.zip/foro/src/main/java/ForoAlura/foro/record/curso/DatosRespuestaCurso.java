package ForoAlura.foro.record.curso;

public record DatosRespuestaCurso(
        Long id,
        String nombre,
        String categoria
) {
}
