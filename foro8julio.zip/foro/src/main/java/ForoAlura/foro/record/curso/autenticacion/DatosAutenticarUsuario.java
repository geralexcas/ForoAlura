package ForoAlura.foro.record.curso.autenticacion;

public record DatosAutenticarUsuario(String nombre, String contrasena) {

}
