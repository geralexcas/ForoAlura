package ForoAlura.foro.record.curso.autenticacion;

public record DatosJwtToken(String jwtToken) {
}
